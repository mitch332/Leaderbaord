# Deploying the H&F Live Leaderboard

## What this version does
- Stores leaderboard data centrally in Supabase.
- Lets an administrator upload seven ContractorsCloud CSV reports.
- Updates every connected office TV within 30 seconds.
- Rotates Monthly Leaders, Yearly Leaders, and Team Standings every 15 seconds.
- Keeps the Supabase service-role key on the server only.

## 1. Create the database
1. Create a Supabase project.
2. Open the SQL editor.
3. Run `supabase_schema.sql`.
4. Copy the project URL and service-role key from the project API settings.

## 2. Deploy the website
1. Upload this folder to a private GitHub repository.
2. Import the repository into Vercel.
3. Add these environment variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `ADMIN_UPLOAD_TOKEN`
4. Set `ADMIN_UPLOAD_TOKEN` to a long private password.
5. Deploy.

## 3. Use it
- TV display: your main website address, such as `https://leaderboard.example.com`
- Report uploads: add `/admin`, such as `https://leaderboard.example.com/admin`
- Upload only the reports that changed and press **Publish Updates**.

## 4. Office TVs
Open the main address in the TV browser and use full-screen or kiosk mode. The page:
- changes boards every 15 seconds;
- checks for new uploads every 30 seconds;
- does not require the TV to be manually refreshed.

## CSV requirements
Individual reports:
- `Rep`
- `Sold`

Team reports:
- `Sold`

All other ContractorsCloud columns are ignored.

## Security notes
- Never expose `SUPABASE_SERVICE_ROLE_KEY` in browser code.
- Keep the `/admin` address and upload token private.
- Use HTTPS, which Vercel supplies automatically.
- Change the upload token whenever an employee with access leaves.
