export default {
  reactStrictMode: true
};
