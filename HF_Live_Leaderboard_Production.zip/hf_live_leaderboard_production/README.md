# H&F Live Leaderboard — Production Version

A deployable Next.js + Supabase leaderboard for H&F Exteriors.

See `DEPLOYMENT.md` for setup instructions.

Main routes:
- `/` — rotating office TV display
- `/admin` — secure CSV report upload page
