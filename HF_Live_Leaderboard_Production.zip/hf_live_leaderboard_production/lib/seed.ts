export const seedData = {
  "updatedAt": "July 28, 2026",
  "monthly": [
    {
      "name": "Paul Moriarity",
      "sales": 207494.32
    },
    {
      "name": "Reggie Trankle",
      "sales": 169730.05
    },
    {
      "name": "Ben Patterson",
      "sales": 143358.36
    },
    {
      "name": "Juan Perez",
      "sales": 117032.03
    },
    {
      "name": "Jill Cochran",
      "sales": 103112.52
    },
    {
      "name": "Bryan Fleming",
      "sales": 87527.41
    }
  ],
  "yearly": [
    {
      "name": "Reggie Trankle",
      "sales": 802817.39
    },
    {
      "name": "Paul Moriarity",
      "sales": 795752.63
    },
    {
      "name": "Jill Cochran",
      "sales": 753489.99
    },
    {
      "name": "Mitchell Nolan",
      "sales": 669875.91
    },
    {
      "name": "Juan Perez",
      "sales": 609384.1
    },
    {
      "name": "AJ Thompson",
      "sales": 559961.95
    }
  ],
  "teams": [
    {
      "name": "Continental Heavyweight",
      "sales": 358600.83
    },
    {
      "name": "Rough Riders",
      "sales": 256996.32
    },
    {
      "name": "Shock Troopers",
      "sales": 235528.97
    },
    {
      "name": "Forged Iron Vanguard",
      "sales": 180332.88
    },
    {
      "name": "Blood, Sweat & Blue",
      "sales": 73243.32
    }
  ]
} as const;
