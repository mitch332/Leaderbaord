export type Leader = { name: string; sales: number };
export type LeaderboardData = {
  updatedAt: string;
  monthly: Leader[];
  yearly: Leader[];
  teams: Leader[];
};
