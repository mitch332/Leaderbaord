import Leaderboard from "./Leaderboard";
export default function Home() { return <Leaderboard />; }
