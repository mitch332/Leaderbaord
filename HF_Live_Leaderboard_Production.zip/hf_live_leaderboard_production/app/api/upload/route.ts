import { NextRequest, NextResponse } from "next/server";
import Papa from "papaparse";
import { adminSupabase } from "@/lib/supabase";
import type { Leader, LeaderboardData } from "@/lib/types";

type CsvRow = Record<string, string>;

const TEAM_NAMES: Record<string, string> = {
  continental: "Continental Heavyweight",
  rough: "Rough Riders",
  shock: "Shock Troopers",
  forged: "Forged Iron Vanguard",
  blue: "Blood, Sweat & Blue"
};

function money(value: unknown): number {
  const parsed = Number(String(value ?? "").replace(/[$,\s]/g, ""));
  return Number.isFinite(parsed) ? parsed : 0;
}

async function parse(file: File): Promise<CsvRow[]> {
  const text = await file.text();
  const result = Papa.parse<CsvRow>(text, { header: true, skipEmptyLines: true });
  if (result.errors.length) throw new Error(result.errors[0].message);
  return result.data;
}

function leaders(rows: CsvRow[]): Leader[] {
  if (!rows.length || !("Rep" in rows[0]) || !("Sold" in rows[0])) {
    throw new Error('Individual reports must contain "Rep" and "Sold" columns.');
  }
  return rows
    .map(row => ({ name: String(row.Rep || "").trim(), sales: money(row.Sold) }))
    .filter(row => row.name)
    .sort((a, b) => b.sales - a.sales)
    .slice(0, 6);
}

function teamTotal(rows: CsvRow[]): number {
  if (!rows.length || !("Sold" in rows[0])) {
    throw new Error('Team reports must contain a "Sold" column.');
  }
  return rows.reduce((sum, row) => sum + money(row.Sold), 0);
}

export async function POST(request: NextRequest) {
  const form = await request.formData();
  const token = String(form.get("token") || "");
  if (!process.env.ADMIN_UPLOAD_TOKEN || token !== process.env.ADMIN_UPLOAD_TOKEN) {
    return NextResponse.json({ error: "Invalid admin token." }, { status: 401 });
  }

  try {
    const supabase = adminSupabase();
    const { data: existing } = await supabase
      .from("leaderboard_state")
      .select("payload")
      .eq("id", 1)
      .single();

    const current: LeaderboardData = existing?.payload || {
      updatedAt: new Date().toISOString(),
      monthly: [],
      yearly: [],
      teams: []
    };

    const monthly = form.get("monthly");
    const yearly = form.get("yearly");
    if (monthly instanceof File && monthly.size) current.monthly = leaders(await parse(monthly));
    if (yearly instanceof File && yearly.size) current.yearly = leaders(await parse(yearly));

    const teamMap = new Map(current.teams.map(t => [t.name, t.sales]));
    for (const [key, name] of Object.entries(TEAM_NAMES)) {
      const file = form.get(key);
      if (file instanceof File && file.size) teamMap.set(name, teamTotal(await parse(file)));
    }
    current.teams = [...teamMap.entries()]
      .map(([name, sales]) => ({ name, sales }))
      .sort((a, b) => b.sales - a.sales);

    current.updatedAt = new Date().toISOString();

    const { error } = await supabase.from("leaderboard_state").upsert({
      id: 1,
      payload: current,
      updated_at: current.updatedAt
    });

    if (error) throw error;
    return NextResponse.json({ ok: true, data: current });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Upload failed.";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
