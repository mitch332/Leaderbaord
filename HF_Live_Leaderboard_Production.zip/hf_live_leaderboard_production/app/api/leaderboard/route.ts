import { NextResponse } from "next/server";
import { adminSupabase } from "@/lib/supabase";
import { seedData } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const supabase = adminSupabase();
    const { data, error } = await supabase
      .from("leaderboard_state")
      .select("payload, updated_at")
      .eq("id", 1)
      .single();

    if (error || !data) return NextResponse.json(seedData);
    return NextResponse.json({ ...data.payload, updatedAt: data.updated_at });
  } catch {
    return NextResponse.json(seedData);
  }
}
