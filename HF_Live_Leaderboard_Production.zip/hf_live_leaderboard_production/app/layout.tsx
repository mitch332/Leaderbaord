import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "H&F Live Leaderboard",
  description: "Live monthly, yearly and team sales standings."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
