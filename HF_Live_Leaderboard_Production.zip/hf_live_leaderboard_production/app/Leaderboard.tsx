'use client';

import { useEffect, useMemo, useState } from "react";
import type { Leader, LeaderboardData } from "@/lib/types";
import { seedData } from "@/lib/seed";

const cash = new Intl.NumberFormat("en-US", {
  style: "currency", currency: "USD", maximumFractionDigits: 0
});

function IndividualBoard({ rows }: { rows: readonly Leader[] }) {
  if (!rows.length) return <div className="card">No report has been uploaded yet.</div>;
  const [first, ...rest] = rows;
  return <>
    <div className="leader">
      <div className="rank-big">1</div>
      <div className="name">{first.name}</div>
      <div className="amount">{cash.format(first.sales)}</div>
    </div>
    <div className="list">
      {rest.map((row, index) => (
        <div className="row" key={row.name}>
          <div className="rank">{index + 2}</div>
          <div className="name">{row.name}</div>
          <div className="amount">{cash.format(row.sales)}</div>
        </div>
      ))}
    </div>
  </>;
}

function TeamBoard({ rows }: { rows: readonly Leader[] }) {
  const max = Math.max(...rows.map(r => r.sales), 1);
  return <div className="list">
    {rows.map((row, index) => (
      <div className="row team-row" key={row.name}>
        <div className="rank">{index + 1}</div>
        <div>
          <div className="name">{row.name}</div>
          <div className="progress"><span style={{ width: `${(row.sales / max) * 100}%` }} /></div>
        </div>
        <div className="amount">{cash.format(row.sales)}</div>
      </div>
    ))}
  </div>;
}

export default function Leaderboard() {
  const [data, setData] = useState<LeaderboardData>(seedData as unknown as LeaderboardData);
  const [slide, setSlide] = useState(0);
  const titles = ["Monthly Leaders", "Yearly Leaders", "Team Standings"];

  useEffect(() => {
    const load = async () => {
      try {
        const response = await fetch("/api/leaderboard", { cache: "no-store" });
        if (response.ok) setData(await response.json());
      } catch {}
    };
    load();
    const refresh = setInterval(load, 30000);
    return () => clearInterval(refresh);
  }, []);

  useEffect(() => {
    const rotate = setInterval(() => setSlide(s => (s + 1) % 3), 15000);
    return () => clearInterval(rotate);
  }, []);

  return <main className="shell">
    <header className="topbar">
      <div className="brand">
        <div className="mark">H&F</div>
        <div>
          <div className="eyebrow">Live Performance Board</div>
          <h1>{titles[slide]}</h1>
        </div>
      </div>
      <div className="meta">
        Updated {new Date(data.updatedAt).toLocaleString()}<br />
        Refreshes every 30 seconds
      </div>
    </header>

    <section className={slide === 0 ? "slide active" : "slide"}>
      <IndividualBoard rows={data.monthly} />
    </section>
    <section className={slide === 1 ? "slide active" : "slide"}>
      <IndividualBoard rows={data.yearly} />
    </section>
    <section className={slide === 2 ? "slide active" : "slide"}>
      <TeamBoard rows={data.teams} />
    </section>

    <div className="dots">
      {[0,1,2].map(i => <span key={i} className={slide === i ? "dot active" : "dot"} />)}
    </div>
  </main>;
}
