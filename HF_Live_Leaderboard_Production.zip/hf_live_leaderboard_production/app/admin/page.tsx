'use client';

import { useState } from "react";

const uploads = [
  ["monthly", "Monthly Leaders"],
  ["yearly", "Yearly Leaders"],
  ["continental", "Continental Heavyweight"],
  ["rough", "Rough Riders"],
  ["shock", "Shock Troopers"],
  ["forged", "Forged Iron Vanguard"],
  ["blue", "Blood, Sweat & Blue"]
] as const;

export default function AdminPage() {
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);

  async function publish(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setStatus("Uploading and calculating standings…");
    try {
      const form = new FormData(event.currentTarget);
      const response = await fetch("/api/upload", { method: "POST", body: form });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Upload failed.");
      setStatus("Published. Office TVs will refresh within 30 seconds.");
      event.currentTarget.reset();
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Upload failed.");
    } finally {
      setBusy(false);
    }
  }

  return <main className="shell">
    <div className="admin-wrap">
      <header className="topbar">
        <div className="brand">
          <div className="mark">H&F</div>
          <div>
            <div className="eyebrow">Secure Report Manager</div>
            <h1 style={{fontSize:48}}>Leaderboard Admin</h1>
          </div>
        </div>
        <a className="button secondary" href="/" target="_blank">Open TV Display</a>
      </header>

      <form onSubmit={publish}>
        <div className="card">
          <h2>Admin access</h2>
          <p>Enter the private upload token configured on the server.</p>
          <input className="admin-input" type="password" name="token" required placeholder="Admin upload token" />
        </div>

        <div className="card">
          <h2>ContractorsCloud reports</h2>
          <p>Upload only the reports you want to replace. Existing boards remain unchanged when a field is left empty.</p>
          <div className="upload-grid">
            {uploads.map(([name, label]) => (
              <label className="upload" key={name}>
                <span>{label}</span>
                <input name={name} type="file" accept=".csv,text/csv" />
              </label>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="actions">
            <button disabled={busy} type="submit">{busy ? "Publishing…" : "Publish Updates"}</button>
            <span className="status" aria-live="polite">{status}</span>
          </div>
        </div>
      </form>
    </div>
  </main>;
}
