create table if not exists public.leaderboard_state (
  id integer primary key,
  payload jsonb not null,
  updated_at timestamptz not null default now()
);

alter table public.leaderboard_state enable row level security;

-- No public policies are required. The application reads and writes through
-- the server using the Supabase service-role key.
